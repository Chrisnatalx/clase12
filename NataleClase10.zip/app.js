const express = require("express");
const Libreria = require("./libreria");
const { Router } = express;

const app = express();
app.use(express.json());
app.use(
  express.urlencoded({
    extended: true,
  })
);

app.set("views", "./views");
app.set("view engine", "ejs");

const router = Router();
const libreria = new Libreria();

router.get("/", (req, res) => {
  return res.json(libreria.list);
});

router.get("/:id", (req, res) => {
  try {
    let id = req.params.id;
    return res.json(libreria.find(id));
  } catch (err) {
    res.json(`Producto no encontrado${err}`);
  }
});

router.post("/", (req, res) => {
  let obj = req.body;
  libreria.insert(obj);
  return res.redirect("/list");
});
router.put("/:id", (req, res) => {
  let obj = req.body;
  let id = req.params.id;
  return res.json(libreria.update(id, obj));
});
router.delete("/:id", (req, res) => {
  let obj = req.body;
  let id = req.params.id;
  return res.json(libreria.delete(id, obj));
});

app.use("/api/productos", router);

app.listen(3000);
app.get("/", (req, res) => {
  return res.render("ejs/form");
});

app.get("/list", (req, res) => {
  return res.render("ejs/list", {
    list: libreria.list,
  });
});
